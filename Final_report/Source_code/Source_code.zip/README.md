# AnToanHeThongTin
Dataset được lấy từ đường links: https://drive.google.com/file/d/1Vtyc0tqB17Wx2J38eiY-oVpWKwjbKMM9/view?usp=drive_link
Dataset được sử dụng file pcap của dữ liệu UNSW-NB15 và tool CICFLOWMETER để thực hiện trích xuất các thuộc tính - Các mô tả phân phối từng loại tấn công của datase CIC-UNSW-NB15 được mô tả trong sheet Result_Demo.xlsx
Các bước chạy - theo tuần tự các bước được ghi cụ thể trong từng file tại đường dẫn syntax: ../Source_code/Demo_[X]/*.ipynb
Các kết quả của lần đo được lưu trữ trong file Result_Demo.xlsx
Các video demo được lưu trữ trong Folder Video_Demo tương ứng.